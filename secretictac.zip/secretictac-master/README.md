secretictac
===========

Desenvolupament del secreticatc.zip de la instal·lació.

Wiki actualitzada amb qüestions de molt interés.
