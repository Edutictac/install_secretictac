secretictac
===========

Desenvolupament del secreticatc.zip de la instal·lació.
