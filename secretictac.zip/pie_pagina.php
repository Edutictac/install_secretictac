
<footer>
<div id="tabla_pie_pagina" ></div>
<table width="100%" height='50px' cellpadding="0" cellspacing="0" border="0" bgcolor="#a8c0fa">
<tr>
<td valign="middle" >
<div id="pie_pagina_div" align='center'>
<?php
echo "© Secretictac 2014";
?>
</div>
</td>
</tr>
</table>
</footer>
