<?php
//tamaños
$tamanyo_pagina="1000";

$color_background='#000000';
$ancho_borde_formularios='1';
$color_borde_formularios='#0000FF';
$color_fondo_formularios='#FFFFFF';
$color_etiquetas='#00000';
$color_texto='#00000';
$color_enlace_antes="#3B5998";
$color_enlace_despues="#DF1602";
$color_titulo="#666666";
$color_campo_no_editable="#FFFF80";
$color_celda_titulo='#eaeaea';
$borde_celda_titulo='1px';
$color_enlace_anyos_antes="#ff0000";
$color_enlace_anyos_despues="#ffffff";
$color_menu_secundario='#000000';
$color_menu_principal='#000000';

//colores listados
//relleno de los rectangulos

$rojo='200';
$verde='200';
$azul='200';

?>
