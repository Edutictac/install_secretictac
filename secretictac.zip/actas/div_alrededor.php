<?php 
$activo='1';
?>
<?php 
include("menu.php");
?>
<div>
<div style="float:left;width:400px;margin:0px 10px 10px 0px">
Este menú lo vimos en viralpatel.net (demo) y nos pareció muy interesante para utilizar con otro estilo. Es muy liviano y utiliza cualquier versión de jQuery que hayamos insertado en nuestro proyecto. Para activar el funcionamiento, bastará con clickear en cualquier sector que contenga subitems, de ser así se despliega un área que nosotros colocaremos con un fondo rayado gris y se contrae cualquier otra área abierta.

Comenzamos con insertar jQuery y elaborar una estructura HTML para el menú.</div>
Este menú lo vimos en viralpatel.net (demo) y nos pareció muy interesante para utilizar con otro estilo. Es muy liviano y utiliza cualquier versión de jQuery que hayamos insertado en nuestro proyecto. Para activar el funcionamiento, bastará con clickear en cualquier sector que contenga subitems, de ser así se despliega un área que nosotros colocaremos con un fondo rayado gris y se contrae cualquier otra área abierta.

Comenzamos con insertar jQuery y elaborar una estructura HTML para el menú.Este menú lo vimos en viralpatel.net (demo) y nos pareció muy interesante para utilizar con otro estilo. Es muy liviano y utiliza cualquier versión de jQuery que hayamos insertado en nuestro proyecto. Para activar el funcionamiento, bastará con clickear en cualquier sector que contenga subitems, de ser así se despliega un área que nosotros colocaremos con un fondo rayado gris y se contrae cualquier otra área abierta.

Comenzamos con insertar jQuery y elaborar una estructura HTML para el menú.Este menú lo vimos en viralpatel.net (demo) y nos pareció muy interesante para utilizar con otro estilo. Es muy liviano y utiliza cualquier versión de jQuery que hayamos insertado en nuestro proyecto. Para activar el funcionamiento, bastará con clickear en cualquier sector que contenga subitems, de ser así se despliega un área que nosotros colocaremos con un fondo rayado gris y se contrae cualquier otra área abierta.

Comenzamos con insertar jQuery y elaborar una estructura HTML para el menú.Este menú lo vimos en viralpatel.net (demo) y nos pareció muy interesante para utilizar con otro estilo. Es muy liviano y utiliza cualquier versión de jQuery que hayamos insertado en nuestro proyecto. Para activar el funcionamiento, bastará con clickear en cualquier sector que contenga subitems, de ser así se despliega un área que nosotros colocaremos con un fondo rayado gris y se contrae cualquier otra área abierta.

Comenzamos con insertar jQuery y elaborar una estructura HTML para el menú.Este menú lo vimos en viralpatel.net (demo) y nos pareció muy interesante para utilizar con otro estilo. Es muy liviano y utiliza cualquier versión de jQuery que hayamos insertado en nuestro proyecto. Para activar el funcionamiento, bastará con clickear en cualquier sector que contenga subitems, de ser así se despliega un área que nosotros colocaremos con un fondo rayado gris y se contrae cualquier otra área abierta.

Comenzamos con insertar jQuery y elaborar una estructura HTML para el menú.</div>